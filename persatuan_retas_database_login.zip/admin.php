<?php require 'config.php'; require_admin();
if($_SERVER['REQUEST_METHOD']==='POST'){
    $action=$_POST['action']??'';
    if($action==='add'){
        $st=$db->prepare("INSERT INTO participants(name,phone,shirt_size,payment,paid) VALUES(?,?,?,?,?)");
        $st->execute([trim($_POST['name']),trim($_POST['phone']),$_POST['shirt_size'],(int)$_POST['payment'],isset($_POST['paid'])?1:0]);
    } elseif($action==='delete'){
        $db->prepare("DELETE FROM participants WHERE id=?")->execute([(int)$_POST['id']]);
    } elseif($action==='toggle'){
        $db->prepare("UPDATE participants SET paid=1-paid WHERE id=?")->execute([(int)$_POST['id']]);
    } elseif($action==='password'){
        $db->prepare("UPDATE admins SET password=? WHERE id=?")->execute([password_hash($_POST['new_password'],PASSWORD_DEFAULT),$_SESSION['admin_id']]);
        $msg='Password berhasil diubah.';
    }
    if($action!=='password'){ header('Location: admin.php'); exit; }
}
$rows=$db->query("SELECT * FROM participants ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
$total=count($rows); $paid=$db->query("SELECT COALESCE(SUM(payment),0) FROM participants WHERE paid=1")->fetchColumn();
$msg=$msg??'';
?><!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin - Persatuan Retas</title>
<style>body{font-family:Arial;background:#f3f4f6;margin:0}.wrap{max-width:1100px;margin:auto;padding:18px}.top{background:#111827;color:#fff;padding:18px;border-radius:14px}.top a{color:#fff;margin-left:12px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:15px;margin-top:15px}.box{background:#fff;padding:18px;border-radius:12px}.box input,.box select,.box button{padding:10px;width:100%;box-sizing:border-box;margin:5px 0}.table{overflow:auto;background:#fff;margin-top:15px;border-radius:12px}table{border-collapse:collapse;width:100%}th,td{padding:10px;border-bottom:1px solid #eee;text-align:left;white-space:nowrap}.btn{border:0;border-radius:7px;background:#111827;color:white;padding:7px 10px}.danger{background:#b91c1c}.ok{color:#166534}</style></head><body><div class="wrap"><div class="top"><b>Panel Admin Persatuan Retas</b><span style="float:right"><a href="index.php">Website</a><a href="logout.php">Logout</a></span></div>
<div class="grid"><form class="box" method="post"><h3>Tambah Peserta</h3><input type="hidden" name="action" value="add"><input name="name" placeholder="Nama peserta" required><input name="phone" placeholder="No. HP"><select name="shirt_size"><option>S</option><option>M</option><option>L</option><option>XL</option><option>XXL</option><option>3XL</option></select><input type="number" name="payment" placeholder="Nominal pembayaran" min="0"><label><input type="checkbox" name="paid" style="width:auto"> Sudah bayar</label><button class="btn">Simpan Peserta</button></form>
<form class="box" method="post"><h3>Ganti Password Admin</h3><input type="hidden" name="action" value="password"><input type="password" name="new_password" placeholder="Password baru" minlength="6" required><button class="btn">Ganti Password</button><?php if($msg):?><p class="ok"><?=h($msg)?></p><?php endif;?></form></div>
<div class="table"><table><tr><th>No</th><th>Nama</th><th>HP</th><th>Ukuran</th><th>Bayar</th><th>Status</th><th>Aksi</th></tr><?php foreach($rows as $i=>$r):?><tr><td><?=$i+1?></td><td><?=h($r['name'])?></td><td><?=h($r['phone'])?></td><td><?=h($r['shirt_size'])?></td><td>Rp <?=number_format($r['payment'],0,',','.')?></td><td><?= $r['paid']?'LUNAS':'BELUM'?></td><td><form method="post" style="display:inline"><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?=$r['id']?>"><button class="btn"><?= $r['paid']?'Batal Lunas':'Tandai Lunas'?></button></form> <form method="post" style="display:inline" onsubmit="return confirm('Hapus data ini?')"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=$r['id']?>"><button class="btn danger">Hapus</button></form></td></tr><?php endforeach;?></table></div></div></body></html>