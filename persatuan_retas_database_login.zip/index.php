<?php require 'config.php';
$rows = $db->query("SELECT * FROM participants ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
$total = count($rows);
$paid = $db->query("SELECT COALESCE(SUM(payment),0) FROM participants WHERE paid=1")->fetchColumn();
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Persatuan Retas - Data Kaos</title><style>
body{font-family:Arial;margin:0;background:#f3f4f6;color:#111}.wrap{max-width:1000px;margin:auto;padding:20px}
header{background:#111827;color:white;padding:24px;border-radius:16px;margin-bottom:16px}h1{margin:0 0 6px}
.cards{display:flex;gap:12px;flex-wrap:wrap}.card{background:white;padding:16px;border-radius:12px;flex:1;min-width:180px;box-shadow:0 2px 8px #0001}
.table{overflow:auto;background:white;border-radius:12px;margin-top:16px}table{width:100%;border-collapse:collapse}th,td{padding:12px;border-bottom:1px solid #eee;text-align:left;white-space:nowrap}
.badge{padding:5px 9px;border-radius:99px;font-size:12px}.yes{background:#dcfce7;color:#166534}.no{background:#fee2e2;color:#991b1b}
a{color:white;text-decoration:none}.admin{float:right;background:#374151;padding:9px 12px;border-radius:8px}
</style></head><body><div class="wrap"><header><a class="admin" href="login.php">Login Admin</a><h1>Persatuan Retas</h1><div>Data peserta & pembayaran kaos</div></header>
<div class="cards"><div class="card"><b><?= $total ?></b><br>Total Peserta</div><div class="card"><b>Rp <?= number_format($paid,0,',','.') ?></b><br>Total Sudah Dibayar</div></div>
<div class="table"><table><tr><th>No</th><th>Nama</th><th>No. HP</th><th>Ukuran</th><th>Pembayaran</th></tr>
<?php foreach($rows as $i=>$r): ?><tr><td><?= $i+1 ?></td><td><?= h($r['name']) ?></td><td><?= h($r['phone']) ?></td><td><?= h($r['shirt_size']) ?></td><td><span class="badge <?= $r['paid']?'yes':'no' ?>"><?= $r['paid']?'LUNAS':'BELUM BAYAR' ?></span></td></tr>
<?php endforeach; if(!$rows): ?><tr><td colspan="5">Belum ada data peserta.</td></tr><?php endif; ?></table></div></div></body></html>