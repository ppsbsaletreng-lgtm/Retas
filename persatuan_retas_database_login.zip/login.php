<?php require 'config.php';
if (!empty($_SESSION['admin_id'])) { header('Location: admin.php'); exit; }
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $stmt=$db->prepare("SELECT * FROM admins WHERE username=?");
    $stmt->execute([$_POST['username'] ?? '']);
    $a=$stmt->fetch(PDO::FETCH_ASSOC);
    if($a && password_verify($_POST['password'] ?? '',$a['password'])){
        $_SESSION['admin_id']=$a['id']; $_SESSION['admin_username']=$a['username'];
        header('Location: admin.php'); exit;
    } $error='Username atau password salah.';
}
?><!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Login Admin</title>
<style>body{font-family:Arial;background:#111827;display:grid;place-items:center;min-height:100vh;margin:0}.box{background:white;padding:28px;border-radius:16px;width:min(360px,85%)}input,button{width:100%;padding:12px;margin:7px 0;box-sizing:border-box;border:1px solid #ddd;border-radius:8px}button{background:#111827;color:white;cursor:pointer}.err{color:#b91c1c}</style></head><body><form class="box" method="post"><h2>Login Admin</h2><?php if($error):?><div class="err"><?=h($error)?></div><?php endif;?><input name="username" placeholder="Username" required><input type="password" name="password" placeholder="Password" required><button>Masuk</button><p><a href="index.php">← Kembali</a></p></form></body></html>