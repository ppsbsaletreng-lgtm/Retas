PERSATUAN RETAS - WEBSITE DATABASE + LOGIN ADMIN

CARA PASANG:
1. Upload semua file ke hosting yang mendukung PHP 8+ dan SQLite/PDO_SQLITE.
2. Buka index.php melalui domain hosting.
3. Buka login.php untuk masuk admin.
4. Login awal:
   Username: admin
   Password: admin123
5. Setelah login, segera ganti password dari panel admin.
6. Database database.sqlite akan dibuat otomatis saat website pertama kali dibuka.

FITUR:
- Halaman publik daftar peserta.
- Login admin.
- Tambah peserta.
- Nomor HP.
- Ukuran kaos.
- Nominal pembayaran.
- Status lunas/belum.
- Tandai/batalkan lunas.
- Hapus peserta.
- Ganti password admin.

CATATAN:
Pastikan hosting mengaktifkan PHP dan PDO SQLite. Untuk keamanan produksi, gunakan HTTPS dan password admin yang kuat.
