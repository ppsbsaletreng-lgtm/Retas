WEBSITE PERSATUAN KAOS
========================
Ini paket awal siap di-upload sebagai website statis.

Cara online paling mudah:
1. Buat akun hosting yang mendukung upload HTML.
2. Upload folder "public" atau isi folder public ke folder website (biasanya public_html).
3. Buka domain/subdomain Anda.

CATATAN:
Versi ini menyimpan contoh data di browser (localStorage), bukan database online.
Untuk database bersama + login admin sungguhan, diperlukan backend (misalnya PHP + MySQL atau layanan database online).
